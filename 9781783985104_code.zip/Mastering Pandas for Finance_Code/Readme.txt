The code files for all the chapters are present.
Also, the Misc folder consists of extra copies of the Python files.